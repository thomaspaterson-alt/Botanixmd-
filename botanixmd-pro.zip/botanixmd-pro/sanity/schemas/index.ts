import post from './post'
import page from './page'
import labReport from './labReport'
export const schemaTypes = [post, page, labReport]
